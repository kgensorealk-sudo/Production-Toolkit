import React, { useState, useEffect, useRef } from 'react';
import { diffLines, diffArrays, Change } from 'diff';
import { ChevronUp, ChevronDown, GitCompare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Toast from '../components/Toast';
import LoadingOverlay from '../components/LoadingOverlay';
import useKeyboardShortcuts from '../hooks/useKeyboardShortcuts';

interface Footnote {
    id: string;
    label: string;
    content: string;
    fullTag: string;
    isNakedMarker?: boolean;
}

const TableFixer: React.FC = () => {
    const [input, setInput] = useState('');
    const [output, setOutput] = useState('');
    const [footnotes, setFootnotes] = useState<Footnote[]>([]);
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [isLoading, setIsLoading] = useState(false);
    const [activeTab, setActiveTab] = useState<'selection' | 'result' | 'diff'>('selection');
    const [toast, setToast] = useState<{msg: string, type: 'success'|'warn'|'error'} | null>(null);
    const [diffRows, setDiffRows] = useState<any[]>([]);
    const [currentChangeIndex, setCurrentChangeIndex] = useState(0);
    const [totalChanges, setTotalChanges] = useState(0);
    const [mode, setMode] = useState<'detach' | 'attach'>('detach');

    const diffContainerRef = useRef<HTMLDivElement>(null);

    // ID Configuration States
    const [tfStart, setTfStart] = useState<number>(4000);
    const [cfStart, setCfStart] = useState<number>(4000);
    const [spStart, setSpStart] = useState<number>(4000);

    const escapeHtml = (unsafe: string) => unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

    const buildLines = (diffParts: Change[], isLeft: boolean) => {
        let lines: string[] = [];
        let currentLine = "";
        let activeClass: string | null = null;

        const append = (text: string, cls: string | null) => {
            if (!text) return;
            for (let i = 0; i < text.length; i++) {
                const char = text[i];
                if (char === '\n') {
                    if (activeClass) currentLine += '</span>';
                    lines.push(currentLine);
                    currentLine = "";
                    if (activeClass) currentLine += `<span class="${activeClass}">`;
                } else {
                    if (cls !== activeClass) {
                        if (activeClass) currentLine += '</span>';
                        activeClass = cls;
                        if (activeClass) currentLine += `<span class="${activeClass}">`;
                    }
                    currentLine += escapeHtml(char);
                }
            }
        };

        diffParts.forEach(part => {
            if (part.removed && isLeft) append(part.value, 'bg-rose-100 text-rose-900 line-through decoration-rose-900/50');
            else if (part.added && !isLeft) append(part.value, 'bg-emerald-200 text-emerald-900 font-bold');
            else if (!part.added && !part.removed) {
                let cls = null;
                if (!isLeft && (part as any).isUnwrapped) {
                    cls = 'bg-amber-100 text-amber-900 font-medium border-b-2 border-amber-300';
                }
                append(part.value, cls);
            }
        });

        if (activeClass) currentLine += '</span>';
        lines.push(currentLine);
        return lines;
    };

    const diffXmlAware = (left: string, right: string): Change[] => {
        const tokenize = (text: string) => text.split(/(<[^>]+>|\s+)/).filter(t => t !== '');
        const leftTokens = tokenize(left);
        const rightTokens = tokenize(right);
        const arrayChanges = diffArrays(leftTokens, rightTokens);
        return arrayChanges.map(part => ({
            value: part.value.join(''),
            count: part.count,
            added: part.added,
            removed: part.removed
        }));
    };

    const generateDiff = (original: string, modified: string) => {
        const diff = diffLines(original, modified);
        let rows: any[] = [];
        let leftLineNum = 1;
        let rightLineNum = 1;
        let changeCounter = 0;

        let i = 0;
        while(i < diff.length) {
            const current = diff[i];
            let type = 'equal';
            let leftVal = '', rightVal = '';

            if (current.removed && diff[i+1]?.added) {
                type = 'replace'; leftVal = current.value; rightVal = diff[i+1].value; i += 2;
            } else if (current.removed) {
                type = 'delete'; leftVal = current.value; i++;
            } else if (current.added) {
                type = 'insert'; rightVal = current.value; i++;
            } else {
                leftVal = rightVal = current.value; i++;
            }

            let leftLines: string[] = [];
            let rightLines: string[] = [];

            if (type === 'replace') {
                const fineDiff = diffXmlAware(leftVal, rightVal);
                for (let k = 0; k < fineDiff.length; k++) {
                    const currentPart = fineDiff[k];
                    if (!currentPart.added && !currentPart.removed) {
                        const prev = k > 0 ? fineDiff[k-1] : null;
                        const next = k < fineDiff.length - 1 ? fineDiff[k+1] : null;
                        if (prev && prev.removed && next && next.removed) {
                            if ((prev.value.includes('ce:cross-ref') || prev.value.includes('<ce:sup>')) && 
                                (next.value.includes('/ce:cross-ref') || next.value.includes('/ce:sup>'))) {
                                (currentPart as any).isUnwrapped = true;
                            }
                        }
                    }
                }
                leftLines = buildLines(fineDiff, true);
                rightLines = buildLines(fineDiff, false);
            } else if (type === 'delete') {
                leftLines = buildLines([{removed: true, value: leftVal} as Change], true);
            } else if (type === 'insert') {
                rightLines = buildLines([{added: true, value: rightVal} as Change], false);
            } else {
                 const lines = leftVal.split('\n');
                 if (lines.length > 0 && lines[lines.length-1] === '') lines.pop(); 
                 leftLines = lines.map(escapeHtml);
                 rightLines = [...leftLines];
            }

            const maxRows = Math.max(leftLines.length, rightLines.length);
            const isChange = type !== 'equal';
            if (isChange) changeCounter++;

            for (let r = 0; r < maxRows; r++) {
                 const lContent = leftLines[r];
                 const rContent = rightLines[r];
                 const lNum = lContent !== undefined ? leftLineNum++ : null;
                 const rNum = rContent !== undefined ? rightLineNum++ : null;
                 
                 rows.push({
                    leftNum: lNum,
                    leftContent: lContent || '',
                    rightNum: rNum,
                    rightContent: rContent || '',
                    type,
                    id: `${i}-${r}`,
                    changeIndex: isChange ? changeCounter : null,
                    isFirstInGroup: isChange && r === 0
                 });
            }
        }
        
        setDiffRows(rows);
        setTotalChanges(changeCounter);
        setCurrentChangeIndex(changeCounter > 0 ? 1 : 0);
    };

    const scrollToChange = (direction: 'next' | 'prev') => {
        if (totalChanges === 0) return;
        
        let targetIndex = direction === 'next' ? currentChangeIndex + 1 : currentChangeIndex - 1;
        if (targetIndex > totalChanges) targetIndex = 1;
        if (targetIndex < 1) targetIndex = totalChanges;
        
        const targetRow = diffContainerRef.current?.querySelector(`[data-change-index-group="${targetIndex}"]`);
        if (targetRow) {
            targetRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setCurrentChangeIndex(targetIndex);
        }
    };

    useEffect(() => {
        if (currentChangeIndex > 0 && diffContainerRef.current) {
            const rows = diffContainerRef.current.querySelectorAll(`[data-change-index="${currentChangeIndex}"]`);
            const allRows = diffContainerRef.current.querySelectorAll('[data-change-index]');
            allRows.forEach(r => r.classList.remove('bg-emerald-100', 'bg-rose-100', 'ring-1', 'ring-emerald-400', 'ring-rose-400', 'z-10', 'relative'));
            
            rows.forEach(row => {
                const type = row.getAttribute('data-type');
                if (type === 'insert' || type === 'replace') {
                    row.classList.add('bg-emerald-100', 'ring-1', 'ring-emerald-400', 'z-10', 'relative');
                } else if (type === 'delete') {
                    row.classList.add('bg-rose-100', 'ring-1', 'ring-rose-400', 'z-10', 'relative');
                }
            });
        }
    }, [currentChangeIndex]);

    useEffect(() => {
        if (!input) {
            setFootnotes([]);
            return;
        }

        const matches: Footnote[] = [];
        
        if (mode === 'detach') {
            const fnRegex = /<ce:table-footnote\b[^>]*?\bid="([^"]+)"[^>]*>([\s\S]*?)<\/ce:table-footnote>/g;
            let match;
            while ((match = fnRegex.exec(input)) !== null) {
                const id = match[1];
                const inner = match[2];
                const fullTag = match[0];
                const labelMatch = /<ce:label[^>]*>([\s\S]*?)<\/ce:label>/.exec(inner);
                const label = labelMatch ? labelMatch[1].trim() : '???';
                const paraMatch = /<ce:note-para[^>]*>([\s\S]*?)<\/ce:note-para>/.exec(inner);
                const content = paraMatch ? paraMatch[1].trim() : '';
                matches.push({ id, label, content, fullTag });
            }
        } else {
            const legendBlocks = input.match(/<ce:legend\b[^>]*>([\s\S]*?)<\/ce:legend>/g) || [];
            
            legendBlocks.forEach(legendMarkup => {
                const spRegex = /<ce:simple-para\b[^>]*>([\s\S]*?)<\/ce:simple-para>/g;
                let spMatch;
                while ((spMatch = spRegex.exec(legendMarkup)) !== null) {
                    const fullTag = spMatch[0];
                    const inner = spMatch[1].trim();
                    let label = '';
                    const labelTagMatch = /^\s*<ce:label>(.*?)<\/ce:label>/.exec(inner);
                    const supMatch = /^\s*<ce:sup>(.*?)<\/ce:sup>/.exec(inner);
                    const boldMatch = /^\s*<ce:bold>(.*?)<\/ce:bold>/.exec(inner);
                    const plainMatch = /^\s*([\*\†\‡\§\⁎a-zA-Z0-9]{1,3})(?:[\.\),\s])/.exec(inner);

                    if (labelTagMatch) label = labelTagMatch[1];
                    else if (supMatch) label = supMatch[1];
                    else if (boldMatch) label = boldMatch[1];
                    else if (plainMatch) label = plainMatch[1];

                    if (label) {
                        const idMatch = /id="([^"]+)"/.exec(fullTag);
                        const id = idMatch ? idMatch[1] : `sp_gen_${matches.length}`;
                        matches.push({ id, label, content: inner, fullTag });
                    }
                }
            });

            const nakedMarkers = ['⁎', '†', '‡', '§', '*'];
            nakedMarkers.forEach(sym => {
                const escapedSym = sym.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                const nakedRegex = new RegExp(`(?<![a-zA-Z0-9])${escapedSym}(?![a-zA-Z0-9])`, 'g');
                
                const occurrences = [...input.matchAll(nakedRegex)];
                const hasValidOccurrence = occurrences.some(occ => {
                    const prevPart = input.substring(0, occ.index);
                    const openCount = (prevPart.match(/</g) || []).length;
                    const closeCount = (prevPart.match(/>/g) || []).length;
                    return openCount === closeCount; 
                });

                if (hasValidOccurrence && !matches.some(m => m.label === sym)) {
                    matches.push({
                        id: `naked_sym_${sym.charCodeAt(0)}`,
                        label: sym,
                        content: `Untagged marker "${sym}" detected.`,
                        fullTag: '',
                        isNakedMarker: true
                    });
                }
            });
        }

        setFootnotes(matches);
        setSelectedIds(new Set(matches.map(m => m.id))); 
        if (matches.length > 0) setActiveTab('selection');
    }, [input, mode]);

    const toggleSelection = (id: string) => {
        const newSet = new Set(selectedIds);
        if (newSet.has(id)) newSet.delete(id);
        else newSet.add(id);
        setSelectedIds(newSet);
    };
    
    const toggleAll = () => {
        if (selectedIds.size === footnotes.length) setSelectedIds(new Set());
        else setSelectedIds(new Set(footnotes.map(f => f.id)));
    };

    const processTable = () => {
        if (!input.trim()) { setToast({ msg: "Please paste XML content first.", type: "warn" }); return; }
        if (selectedIds.size === 0) { setToast({ msg: "Select at least one item to process.", type: "warn" }); return; }

        setIsLoading(true);
        setTimeout(() => {
            const tableRegex = /<ce:table\b[\s\S]*?<\/ce:table>/g;
            const tableBlocks = input.match(tableRegex) || [input];
            
            let totalProcessedCount = 0;

            if (mode === 'detach') {
                let spIdCounter = spStart;
                
                const processedBlocks = tableBlocks.map(tableMarkup => {
                    let currentTable = tableMarkup;
                    let legendsToAdd: string[] = [];
                    const tableFootnotes = footnotes.filter(fn => selectedIds.has(fn.id) && tableMarkup.includes(fn.fullTag));
                    
                    tableFootnotes.forEach(fn => {
                        const refRegex = new RegExp(`<ce:cross-ref\\b[^>]*?refid="${fn.id}"[^>]*>([\\s\\S]*?)<\\/ce:cross-ref>`, 'g');
                        
                        const isStandardAsterisk = fn.label.trim() === '*';

                        currentTable = currentTable.replace(refRegex, (m, content) => {
                            if (isStandardAsterisk) {
                                return content.replace(/<ce:sup>|<\/ce:sup>/g, '');
                            } else {
                                return content.includes('<ce:sup>') ? content : `<ce:sup>${content}</ce:sup>`;
                            }
                        });
                        
                        currentTable = currentTable.split(fn.fullTag).join('');
                        const spId = `sp${spIdCounter.toString().padStart(4, '0')}`;
                        spIdCounter += 5;
                        
                        const labelMarkup = isStandardAsterisk ? fn.label : `<ce:sup>${fn.label}</ce:sup>`;
                        legendsToAdd.push(`<ce:simple-para id="${spId}">${labelMarkup} ${fn.content}</ce:simple-para>`);
                        totalProcessedCount++;
                    });

                    if (legendsToAdd.length > 0) {
                        const legendMarkup = legendsToAdd.join('');
                        const existingLegendMatch = currentTable.match(/<ce:legend\b[^>]*>([\s\S]*?)<\/ce:legend>/i);
                        
                        if (existingLegendMatch) {
                            // Single Injection point: Append to existing legend before its closing tag
                            currentTable = currentTable.replace(/<\/ce:legend>/i, `${legendMarkup}</ce:legend>`);
                        } else {
                            // No legend exists: Find </tgroup> and insert a new legend after it
                            const tgroupEndMatch = currentTable.match(/<\/tgroup>/i);
                            if (tgroupEndMatch) {
                                currentTable = currentTable.replace(/<\/tgroup>/i, `</tgroup><ce:legend>${legendMarkup}</ce:legend>`);
                            } else {
                                // Fallback: Inject before end of table
                                currentTable = currentTable.replace(/<\/ce:table>/i, `<ce:legend>${legendMarkup}</ce:legend></ce:table>`);
                            }
                        }
                    }
                    return currentTable;
                });

                const finalOutput = processedBlocks.join('\n\n');
                setOutput(finalOutput);
                generateDiff(input, finalOutput);
                setToast({ msg: `Moved ${totalProcessedCount} footnotes to consolidated legend.`, type: "success" });

            } else {
                let tfIdCounter = tfStart;
                let cfIdCounter = cfStart;

                const sortedSelected = footnotes
                    .filter(fn => selectedIds.has(fn.id))
                    .sort((a, b) => b.label.length - a.label.length);

                const processedBlocks = tableBlocks.map(tableMarkup => {
                    let currentTable = tableMarkup;
                    let footnotesToAdd: string[] = [];
                    const replacementMap = new Map<string, string>();

                    sortedSelected.forEach((fn, index) => {
                        const labelStr = fn.label;
                        const escapedLabel = labelStr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                        
                        // Captures optional surrounding formatting tags for relocation inside cross-ref
                        const existingTagged = `(?:<ce:cross-ref\\b[^>]*>\\s*)?(?:<ce:(?:sup|bold|italic)>\\s*)*${escapedLabel}(?:\\s*<\\/ce:(?:sup|bold|italic)>)*(?:\\s*<\\/ce:cross-ref>)?`;
                        const nakedPattern = `(?<![a-zA-Z0-9])${escapedLabel}(?![a-zA-Z0-9])`;
                        const targetRegex = new RegExp(`(${existingTagged}|${nakedPattern})`, 'g');

                        const isPresentInTable = (fn.fullTag && currentTable.includes(fn.fullTag)) || (!fn.fullTag && targetRegex.test(currentTable));
                        
                        if (isPresentInTable) {
                            const numericPart = String(tfIdCounter).padStart(4, '0');
                            const newFnId = `tf${numericPart}`;
                            const newNpId = `np${numericPart}`;
                            tfIdCounter += 5;
                            
                            if (fn.fullTag) currentTable = currentTable.split(fn.fullTag).join('');
                            
                            const isStandardAsterisk = fn.label.trim() === '*';

                            currentTable = currentTable.replace(targetRegex, (match) => {
                                const placeholder = `##TF_PH_${index}_${cfIdCounter}_${Math.random().toString(36).substring(7)}##`;
                                const newCfId = `cf${cfIdCounter.toString().padStart(4, '0')}`;
                                cfIdCounter += 5;

                                const hasBold = match.includes('<ce:bold');
                                const hasItalic = match.includes('<ce:italic');
                                const shouldHaveSup = !isStandardAsterisk;

                                // DTD HIERARCHY: cross-ref > sup > bold > italic > Label
                                let innermost = fn.label;
                                if (hasItalic) innermost = `<ce:italic>${innermost}</ce:italic>`;
                                if (hasBold) innermost = `<ce:bold>${innermost}</ce:bold>`;
                                if (shouldHaveSup) innermost = `<ce:sup>${innermost}</ce:sup>`;
                                
                                const finalTag = `<ce:cross-ref id="${newCfId}" refid="${newFnId}">${innermost}</ce:cross-ref>`;
                                
                                replacementMap.set(placeholder, finalTag);
                                return placeholder;
                            });

                            const stripPattern = new RegExp(`^\\s*(?:<ce:(?:label|sup|bold|italic)>)*\\s*${escapedLabel}\\s*(?:<\\/ce:(?:label|sup|bold|italic)>|[\\.,\\)\\s])+`, 'i');
                            let cleanContent = fn.content.replace(stripPattern, '').trim();
                            if (!cleanContent) cleanContent = '??';
                            
                            footnotesToAdd.push(`<ce:table-footnote id="${newFnId}"><ce:label>${fn.label}</ce:label><ce:note-para id="${newNpId}">${cleanContent}</ce:note-para></ce:table-footnote>`);
                            totalProcessedCount++;
                        }
                    });

                    replacementMap.forEach((xml, placeholder) => {
                        currentTable = currentTable.split(placeholder).join(xml);
                    });

                    if (footnotesToAdd.length > 0) {
                        const footnotesMarkup = footnotesToAdd.join('');
                        const lastLegendIdx = currentTable.lastIndexOf('</ce:legend>');
                        const lastTgroupIdx = currentTable.lastIndexOf('</tgroup>');
                        
                        const legendEnd = lastLegendIdx !== -1 ? lastLegendIdx + '</ce:legend>'.length : -1;
                        const tgroupEnd = lastTgroupIdx !== -1 ? lastTgroupIdx + '</tgroup>'.length : -1;
                        const insertionPoint = Math.max(legendEnd, tgroupEnd);

                        if (insertionPoint !== -1) {
                            const before = currentTable.slice(0, insertionPoint);
                            const after = currentTable.slice(insertionPoint);
                            currentTable = `${before}${footnotesMarkup}${after}`;
                        } else {
                            currentTable = currentTable.replace('</ce:table>', `${footnotesMarkup}</ce:table>`);
                        }
                    }
                    currentTable = currentTable.replace(/<ce:legend>\s*<\/ce:legend>/g, '');
                    return currentTable;
                });

                const finalOutput = processedBlocks.join('\n\n');
                setOutput(finalOutput);
                generateDiff(input, finalOutput);
                setToast({ msg: `Attached ${totalProcessedCount} items with correct hierarchy.`, type: "success" });
            }

            setActiveTab('result');
            setIsLoading(false);
        }, 600);
    };

    useKeyboardShortcuts({
        onPrimary: processTable,
        onCopy: () => { if (output && activeTab === 'result') { navigator.clipboard.writeText(output); setToast({msg: 'Copied output!', type:'success'}); } },
        onClear: () => { setInput(''); setFootnotes([]); setOutput(''); }
    }, [input, output, footnotes, selectedIds, activeTab, mode, tfStart, cfStart, spStart]);

    const themeColor = mode === 'detach' ? 'pink' : 'blue';

    return (
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
            <div className="mb-8 text-center animate-fade-in">
                <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight sm:text-4xl mb-3 uppercase tracking-tighter">XML Table Fixer Pro</h1>
                <p className="text-lg text-slate-500 max-w-2xl mx-auto font-medium">Surgical footnote management. DTD-strict nesting hierarchy and consolidated legends.</p>
            </div>

            {/* Configuration Bar */}
            <div className="flex justify-center mb-6">
                <div className="bg-white px-6 py-4 rounded-2xl shadow-sm border border-slate-200 flex flex-wrap items-center gap-8">
                    <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${mode === 'detach' ? 'bg-pink-50 text-pink-600' : 'bg-blue-50 text-blue-600'}`}>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" /></svg>
                        </div>
                        <span className="text-xs font-bold text-slate-700 uppercase tracking-widest">ID Matrix Config</span>
                    </div>
                    
                    <div className="flex items-center gap-6">
                        <div className="flex flex-col gap-1">
                            <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">Footnote/Para (tf/np)</label>
                            <input 
                                type="number" 
                                value={tfStart} 
                                onChange={(e) => setTfStart(parseInt(e.target.value) || 0)} 
                                className="w-24 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-sm font-mono font-bold text-slate-700 outline-none focus:ring-2 focus:ring-slate-100 transition-all"
                            />
                        </div>
                        <div className="flex flex-col gap-1">
                            <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">Cross-Ref (cf)</label>
                            <input 
                                type="number" 
                                value={cfStart} 
                                onChange={(e) => setCfStart(parseInt(e.target.value) || 0)} 
                                className="w-24 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-sm font-mono font-bold text-slate-700 outline-none focus:ring-2 focus:ring-slate-100 transition-all"
                            />
                        </div>
                        <div className="flex flex-col gap-1">
                            <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">Legend Para (sp)</label>
                            <input 
                                type="number" 
                                value={spStart} 
                                onChange={(e) => setSpStart(parseInt(e.target.value) || 0)} 
                                className="w-24 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-sm font-mono font-bold text-slate-700 outline-none focus:ring-2 focus:ring-slate-100 transition-all"
                            />
                        </div>
                    </div>
                </div>
            </div>

            <div className="flex justify-center mb-8">
                <div className="bg-slate-100 p-1 rounded-xl flex shadow-inner">
                    <button onClick={() => setMode('detach')} className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all ${mode === 'detach' ? 'bg-white text-pink-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>Detach (Footnote &rarr; Legend)</button>
                    <button onClick={() => setMode('attach')} className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all ${mode === 'attach' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>Attach (Legend &rarr; Footnote)</button>
                </div>
            </div>

            <div className={`grid gap-8 h-[600px] transition-all duration-300 ${activeTab === 'diff' ? 'grid-cols-1' : 'grid-cols-1 lg:grid-cols-2'}`}>
                <div className={`bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col group focus-within:ring-2 ${mode === 'detach' ? 'focus-within:ring-pink-100' : 'focus-within:ring-blue-100'} transition-all duration-300 ${activeTab === 'diff' ? 'hidden' : 'flex'}`}>
                    <div className="bg-slate-50 px-5 py-3 border-b border-slate-100 flex justify-between items-center">
                        <label className="font-bold text-slate-700 text-sm flex items-center gap-2"><span className="flex h-6 w-6 items-center justify-center rounded-md bg-white border border-slate-200 text-xs text-slate-500 font-mono shadow-sm">1</span>Input XML</label>
                        <div className="flex gap-2">
                             {footnotes.length > 0 && <span className={`text-xs font-medium px-2 py-1 rounded-md border flex items-center gap-1 ${mode === 'detach' ? 'text-pink-600 bg-pink-50 border-pink-100' : 'text-blue-600 bg-blue-50 border-blue-100'}`}><svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>{footnotes.length} Detected</span>}
                             <button onClick={() => { setInput(''); setFootnotes([]); }} className="text-xs font-semibold text-slate-400 hover:text-red-500 hover:bg-red-50 px-2 py-1 rounded transition-colors">Clear</button>
                        </div>
                    </div>
                    <textarea value={input} onChange={(e) => setInput(e.target.value)} className="w-full h-full p-6 text-sm font-mono text-slate-800 border-0 focus:ring-0 outline-none bg-white resize-none leading-relaxed placeholder-slate-300" placeholder={mode === 'detach' ? "Paste <ce:table> containing footnotes..." : "Paste <ce:table> containing legend items..."} spellCheck={false} />
                </div>

                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col relative">
                     <div className="flex border-b border-slate-100 bg-slate-50">
                        <button onClick={() => setActiveTab('selection')} className={`flex-1 py-3 text-sm font-bold transition-all border-r border-slate-100 ${activeTab === 'selection' ? `bg-white ${mode === 'detach' ? 'text-pink-600' : 'text-blue-600'}` : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'}`}><span className="flex items-center justify-center gap-2"><span className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] ${activeTab === 'selection' ? (mode === 'detach' ? 'bg-pink-100 text-pink-600' : 'bg-blue-100 text-blue-600') : 'bg-slate-200 text-slate-500'}`}>2</span>Selection</span></button>
                        <button onClick={() => setActiveTab('result')} className={`flex-1 py-3 text-sm font-bold transition-all border-r border-slate-100 ${activeTab === 'result' ? `bg-white text-emerald-600` : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100'}`}><span className="flex items-center justify-center gap-2"><span className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] ${activeTab === 'result' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-200 text-slate-500'}`}>3</span>Result</span></button>
                        <button onClick={() => setActiveTab('diff')} className={`flex-1 py-3 text-sm font-bold transition-all ${activeTab === 'diff' ? 'bg-white text-orange-600' : 'text-slate-500 hover:text-slate-700'}`}><span className="flex items-center justify-center gap-2"><span className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] ${activeTab === 'diff' ? 'bg-orange-100 text-orange-600' : 'bg-slate-200 text-slate-500'}`}>4</span>Diff</span></button>
                     </div>

                    <div className="flex-grow relative overflow-hidden bg-slate-50/50">
                        {isLoading && <LoadingOverlay message={mode === 'detach' ? "Detaching..." : "Attaching..."} color={themeColor} />}

                        {activeTab === 'selection' && (
                            <div className="h-full flex flex-col">
                                {footnotes.length === 0 ? (
                                    <div className="h-full flex flex-col items-center justify-center text-slate-400 p-8 text-center opacity-60"><svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mb-3 text-slate-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg><p className="text-sm font-medium">No items found.</p><p className="text-xs mt-1">Paste XML containing {mode === 'detach' ? 'footnotes' : 'legend items'}.</p></div>
                                ) : (
                                    <>
                                        <div className="p-3 bg-white border-b border-slate-100 flex justify-between items-center shadow-sm z-10"><div className="text-xs text-slate-500 font-medium pl-1">Select items to process:</div><button onClick={toggleAll} className={`text-xs font-semibold text-slate-600 px-2 py-1 rounded transition-colors ${mode === 'detach' ? 'hover:text-pink-600 hover:bg-pink-50' : 'hover:text-blue-600 hover:bg-blue-50'}`}>{selectedIds.size === footnotes.length ? 'Deselect All' : 'Select All'}</button></div>
                                        <div className="flex-grow overflow-y-auto p-4 custom-scrollbar space-y-3">
                                            {footnotes.map(fn => (
                                                <label key={fn.id} className={`relative flex items-start gap-3 p-4 bg-white border rounded-xl cursor-pointer transition-all duration-200 group ${selectedIds.has(fn.id) ? (mode === 'detach' ? 'border-pink-500 shadow-md shadow-pink-100 ring-1 ring-pink-500' : 'border-blue-500 shadow-md shadow-blue-100 ring-1 ring-blue-500') : `border-slate-200 ${mode === 'detach' ? 'hover:border-pink-300' : 'hover:border-blue-300'} hover:shadow-sm`}`}>
                                                    <div className="pt-0.5"><input type="checkbox" checked={selectedIds.has(fn.id)} onChange={() => toggleSelection(fn.id)} className={`rounded border-slate-300 w-4 h-4 cursor-pointer ${mode === 'detach' ? 'text-pink-600 focus:ring-pink-500' : 'text-blue-600 focus:ring-blue-500'}`} /></div>
                                                    <div className="flex-grow min-w-0">
                                                        <div className="flex items-center justify-between mb-1">
                                                            <div className="flex items-center gap-2">
                                                                <span className="text-[10px] font-mono font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200 uppercase tracking-tighter">{fn.id}</span>
                                                                <span className="text-sm font-bold text-slate-800 flex items-center gap-1">Label: <span className={`px-1.5 rounded ${mode === 'detach' ? 'bg-pink-50 text-pink-700' : 'bg-blue-50 text-blue-700'}`}>{fn.label}</span></span>
                                                                {fn.isNakedMarker && <span className="text-[9px] font-black uppercase bg-rose-100 text-rose-600 px-1.5 py-0.5 rounded border border-rose-200">Naked Marker</span>}
                                                            </div>
                                                        </div>
                                                        <div className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-2 rounded border border-slate-100 font-mono break-words" dangerouslySetInnerHTML={{__html: fn.content || '<span class="italic text-slate-400">Empty content</span>'}}></div>
                                                    </div>
                                                </label>
                                            ))}
                                        </div>
                                    </>
                                )}
                            </div>
                        )}

                        {activeTab === 'result' && (
                            <div className="h-full flex flex-col">
                                <div className="bg-white p-2 border-b border-slate-100 flex justify-between items-center z-10"><div className="text-xs text-slate-500 pl-2">Output contains {output.length} chars</div><button onClick={() => { navigator.clipboard.writeText(output); setToast({msg: "Copied!", type: "success"})}} className="text-xs font-bold text-emerald-600 hover:bg-emerald-50 px-3 py-1.5 rounded border border-emerald-100 hover:border-emerald-200 transition-colors flex items-center gap-1"><svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" /></svg>Copy to Clipboard</button></div>
                                <div className="flex-grow relative"><textarea value={output} readOnly className="w-full h-full p-6 text-sm font-mono text-slate-800 border-0 focus:ring-0 outline-none bg-white resize-none leading-relaxed placeholder-slate-300" placeholder="Processed XML will appear here after conversion..." />{!output && <div className="absolute inset-0 flex items-center justify-center pointer-events-none"><p className="text-slate-300 text-sm">Waiting for conversion...</p></div>}</div>
                            </div>
                        )}

                        {activeTab === 'diff' && (
                             <div className="absolute inset-0 overflow-hidden bg-white flex flex-col">
                                {diffRows.length > 0 ? (
                                    <>
                                        <div ref={diffContainerRef} className="flex-grow overflow-auto custom-scrollbar relative">
                                            <table className="w-full text-sm font-mono border-collapse table-fixed bg-white">
                                                <colgroup>
                                                    <col className="w-12 bg-slate-50 border-r border-slate-200" />
                                                    <col className="w-[calc(50%-3rem)]" />
                                                    <col className="w-12 bg-slate-50 border-r border-slate-200 border-l border-slate-200" />
                                                    <col className="w-[calc(50%-3rem)]" />
                                                </colgroup>
                                                <tbody>
                                                    {diffRows.map((row) => {
                                                        let lClass = row.leftNum !== null && row.type === 'delete' ? 'bg-rose-50/50' : (row.type === 'replace' ? 'bg-rose-50/30' : '');
                                                        let rClass = row.rightNum !== null && row.type === 'insert' ? 'bg-emerald-50/50' : (row.type === 'replace' ? 'bg-emerald-50/30' : '');
                                                        if (row.type === 'equal') { lClass = ''; rClass = ''; }

                                                        return (
                                                            <tr 
                                                                key={row.id} 
                                                                className="border-b border-slate-100 hover:bg-slate-50 transition-colors duration-75"
                                                                data-change-index={row.changeIndex}
                                                                data-change-index-group={row.isFirstInGroup ? row.changeIndex : undefined}
                                                                data-type={row.type}
                                                            >
                                                                <td className={`w-12 text-right text-xs text-slate-400 p-1 border-r border-slate-200 select-none bg-slate-50 font-mono ${lClass}`}>{row.leftNum || ''}</td>
                                                                <td className={`p-1 font-mono text-sm text-slate-700 whitespace-pre-wrap break-all leading-tight ${lClass}`} dangerouslySetInnerHTML={{__html: row.leftContent || ''}}></td>
                                                                <td className={`w-12 text-right text-xs text-slate-400 p-1 border-r border-slate-200 border-l select-none bg-slate-50 font-mono ${rClass}`}>{row.rightNum || ''}</td>
                                                                <td className={`p-1 font-mono text-sm text-slate-700 whitespace-pre-wrap break-all leading-tight ${rClass}`} dangerouslySetInnerHTML={{__html: row.rightContent || ''}}></td>
                                                            </tr>
                                                        );
                                                    })}
                                                </tbody>
                                            </table>
                                        </div>

                                        {/* Floating Diff Navigation */}
                                        <AnimatePresence>
                                            {totalChanges > 0 && (
                                                <motion.div 
                                                    initial={{ opacity: 0, y: 20, scale: 0.95 }}
                                                    animate={{ opacity: 1, y: 0, scale: 1 }}
                                                    exit={{ opacity: 0, y: 20, scale: 0.95 }}
                                                    className="absolute bottom-8 right-8 flex items-center gap-2 bg-white/90 backdrop-blur-xl border border-slate-200/50 rounded-2xl p-2 shadow-[0_20px_50px_rgba(0,0,0,0.15)] z-30 ring-1 ring-slate-900/5"
                                                >
                                                    <div className="flex items-center gap-1 pr-2 border-r border-slate-100">
                                                        <div className="w-8 h-8 rounded-xl bg-indigo-50 flex items-center justify-center">
                                                            <GitCompare className="w-4 h-4 text-indigo-600" strokeWidth={2.5} />
                                                        </div>
                                                        <div className="flex flex-col px-2">
                                                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter leading-none mb-0.5">Changes</span>
                                                            <span className="text-xs font-black text-slate-900 tabular-nums leading-none">
                                                                {currentChangeIndex} <span className="text-slate-300 mx-0.5">/</span> {totalChanges}
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div className="flex items-center gap-1">
                                                        <button 
                                                            onClick={() => scrollToChange('prev')}
                                                            className="p-2.5 hover:bg-slate-100 active:bg-slate-200 rounded-xl transition-all text-slate-600 hover:text-indigo-600 group"
                                                            title="Previous Change (Shift+Tab)"
                                                        >
                                                            <ChevronUp className="w-5 h-5 group-active:-translate-y-0.5 transition-transform" strokeWidth={3} />
                                                        </button>
                                                        <button 
                                                            onClick={() => scrollToChange('next')}
                                                            className="p-2.5 hover:bg-slate-100 active:bg-slate-200 rounded-xl transition-all text-slate-600 hover:text-indigo-600 group"
                                                            title="Next Change (Tab)"
                                                        >
                                                            <ChevronDown className="w-5 h-5 group-active:translate-y-0.5 transition-transform" strokeWidth={3} />
                                                        </button>
                                                    </div>
                                                </motion.div>
                                            )}
                                        </AnimatePresence>
                                    </>
                                ) : (
                                    <div className="h-full flex flex-col items-center justify-center text-slate-400 opacity-60">
                                        <GitCompare size={48} strokeWidth={1} className="mb-3 text-slate-300" />
                                        <p className="text-sm font-medium uppercase tracking-widest">Run conversion to see differences.</p>
                                    </div>
                                )}
                             </div>
                        )}
                    </div>
                </div>
            </div>

            <div className="mt-8 text-center">
                <button onClick={processTable} disabled={selectedIds.size === 0 || isLoading} className={`group font-bold py-3.5 px-10 rounded-xl shadow-lg transform transition-all active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed hover:-translate-y-0.5 ${mode === 'detach' ? 'bg-pink-600 hover:bg-pink-700 text-white shadow-pink-500/30' : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/30'}`}>{mode === 'detach' ? 'Convert Selection to Legend' : 'Attach Selection as Footnotes'}</button>
            </div>
            {toast && <Toast message={toast.msg} type={toast.type} onClose={() => setToast(null)} />}
        </div>
    );
};

export default TableFixer;